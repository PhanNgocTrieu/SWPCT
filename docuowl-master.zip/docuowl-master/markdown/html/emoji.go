package html

//go:generate go run ../../generators/markdown-emoji.go
